let info = document.querySelector('.info')
let btn = document.querySelector('.btn')
let eft = document.querySelector('.eft')
let inputName = document.querySelector('.inputName')
let inputMsg = document.querySelector('.inputMsg')


let h = hora()

btn.onclick = () => {

    if( inputName.value == 0 || inputMsg.value == 0){
        eft.classList.add('vazio')
        return 
    }

    btn.setAttribute('disabled', 1)
    eft.classList.add('enviando')
    btn.innerText = 'Enviando'

    console.log({Nome: inputName.value, Mensagem: inputMsg.value, DataHora: h })

    info.style.display = 'flex'

    setTimeout(() => {
        info.style.display = "none"
        btn.removeAttribute('disabled')
      }, 2000)
}

////--- Remove borda vermelha --- /////

document.querySelectorAll('.input').forEach((inputs)=>{
    inputs.addEventListener('input', (e)=>{
        if(eft.classList.contains('vazio')){
            eft.classList.remove('vazio')
        }
    })
})
/* input.addEventListener('input', (e)=>{
    if(eft.classList.contains('vazio')){
        eft.classList.remove('vazio')
    }
}) */